package Thread_Example;
public class Thread_Example implements Runnable {
	  private String name;

	  public Thread_Example(String name) {
	    this.name = name;
	  }

	  @Override
	  public void run() {
	    System.out.println("Thread started: " + name);
	    try {
	      Thread.sleep(500);
	    } catch (InterruptedException e) {
	      e.printStackTrace();
	    }
	    System.out.println("Thread ended: " + name);
	  }

	  public static void main(String[] args) {
	    Thread_Example runnableExample1 = new Thread_Example("Thread-1");
	    Thread_Example runnableExample2 = new Thread_Example("Thread-2");
	    Thread_Example runnableExample3 = new Thread_Example("Thread-3");
	    Thread thread1 = new Thread(runnableExample1);
	    Thread thread2 = new Thread(runnableExample2);
	    Thread thread3 = new Thread(runnableExample3);
	    thread1.start();
	    thread2.start();
	    thread3.start();
	  }
	}

