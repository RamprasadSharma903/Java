/**
 * 
 */
/**
 * 
 */
module Resizeable {
}