package pkg1;

public class OuterInner {
	  public void display() {
	    System.out.println("Outer class display method:");
	    System.out.println("In Java, first outer class will execute...");
	  }

	  class Inner {
	    public void display() {
	      System.out.println("Inner class display method:");
	      System.out.println("After outer class, inner class will execute...");
	    }
	  }

	  public static void main(String[] args) {
	    OuterInner outer = new OuterInner();
	    outer.display();
	    OuterInner.Inner inner = outer.new Inner();
	    inner.display();
	  }
	}
