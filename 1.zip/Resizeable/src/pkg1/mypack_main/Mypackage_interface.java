package pkg1.mypack_main;

public interface Mypackage_interface {
  void display();
}

public class MyClass implements Mypackage_interface {
  public void display() {
    System.out.println("Hello!");
    System.out.println("Hi...");
    System.out.println("You -)");
    System.out.println("Yes You..");
    System.out.println("Hello, You only.");
    System.out.println("this is the result-)-)-)");
  }
}

// You need to move this class to a separate file named Mypack_main.java
// and place it in the same package as MyClass
public class Myclass {
  public static void main(String[] args) {
    // You need to import pkg1.MyClass instead of mypack.MyClass
    // since they are in the same package
    pkg1.MyClass obj = new pkg1.MyClass();
    obj.display();
  }
}
