package mypack;

public class MyClass {

}
