package mypack;
public interface Mypackage_interface {
 void display(); 
}


class Mypack_main implements Mypackage_interface{

 
 public void display() {
 System.out.println("Hello!");
 System.out.println("Hi...");
 System.out.println("You -)");
 System.out.println("Yes You..");
 System.out.println("Hello, You only.");
 System.out.println("this is the result-)-)-)");
 } 
}

import mypack.MyClass_main; 
 class Mypack_main1 {
 public static void main(String[] args) {
 // Create an object of MyClass
 Mypack_main obj = new Mypack_main();
 // Call the display() method of MyClass
 obj.display();
 	} 
 }