// Mypackage_interface.java
package Mypack_main;
public interface Mypackage_interface {
 void display(); 
}

// Mypack_main.java
package Mypack_main;
public class Mypack_main implements Mypackage_interface{

 
 public void display() {
 System.out.println("Hello!");
 System.out.println("Hi...");
 System.out.println("You -)");
 System.out.println("Yes You..");
 System.out.println("Hello, You only.");
 System.out.println("this is the result-)-)-)");
 } 
}

// Mypack_main1.java
package Mypack_main;
class Mypack_main1 {
 public static void main(String[] args) {
 // Create an object of Mypack_main
 Mypack_main obj = new Mypack_main();
 // Call the display() method of Mypack_main
 obj.display();
 	} 
 }
