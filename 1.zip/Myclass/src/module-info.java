/**
 * 
 */
/**
 * 
 */
module Myclass {
}