package MyThread;

public class MyThread extends Thread {
	  public MyThread() {
	    super();
	    System.out.println("Child Thread");
	  }

	  @Override
	  public void run() {
	    try {
	      for (int i = 0; i < 5; i++) {
	        System.out.println("Child Thread: " + i);
	        Thread.sleep(500);
	      }
	    } catch (InterruptedException e) {
	      e.printStackTrace();
	    }
	  }

	  public static void main(String[] args) {
	    MyThread myThread = new MyThread();
	    myThread.start();
	    try {
	      for (int i = 0; i < 5; i++) {
	        System.out.println("Main Thread: " + i);
	        Thread.sleep(500);
	      }
	    } catch (InterruptedException e) {
	      e.printStackTrace();
	    }
	  }
	}
