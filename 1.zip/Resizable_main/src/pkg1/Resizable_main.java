package pkg1;

interface Resizable {

	 void resizeWidth(int width);

	 void resizeHeight(int height);

	}



	class Rectangle implements Resizable {

	 private int width;

	 private int height;



	 public Rectangle(int width, int height) {

	  this.width = width;

	  this.height = height;

	 }



	 @Override

	 public void resizeWidth(int width) {

	  this.width = width;

	 }



	 @Override

	 public void resizeHeight(int height) {

	  this.height = height;

	 }



	 public int getWidth() {

	  return width;

	 }



	 public int getHeight() {

	  return height;

	 }

	}



	class Resizable_main {

	 public static void main(String args[]) {

	  Rectangle rectangle = new Rectangle(10, 20);

	  System.out.println("Original width: " + rectangle.getWidth());

	  System.out.println("Original height: " + rectangle.getHeight());

	  rectangle.resizeWidth(30);

	  rectangle.resizeHeight(40);

	  System.out.println("New width: " + rectangle.getWidth());

	  System.out.println("New height: " + rectangle.getHeight());

	 }

	}