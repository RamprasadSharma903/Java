package pkg1;

import java.util.Scanner;

public class Employee {

    private int id;
    private String name;
    private double salary;

    public Employee(int id, String name, double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }

    public void raiseSalary(double percent) {
        double increase = salary * percent / 100;
        salary += increase;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getSalary() {
        return salary;
    }

    public String toString() {
        return "Employee{" + "name=" + name + ", id=" + id + ", Salary=" + salary + '}';
    }

    public static void main(String[] args) {
        Employee employee = new Employee(123, "Rohan", 75000);

        System.out.println("Employee before salary increase: " + employee);
        System.out.println("Enter how much percent increment you want to give to employee:");
        try (Scanner sc = new Scanner(System.in)) {
			double i = sc.nextDouble();
			employee.raiseSalary(i);
		}
        System.out.println("Employee salary after increase: " + employee);
    }
}
